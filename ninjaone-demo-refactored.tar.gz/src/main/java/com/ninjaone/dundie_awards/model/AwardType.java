package com.ninjaone.dundie_awards.model;

public enum AwardType {
    HELPED_TEAMMATE,
    COMPLETED_PROJECT,
    MENTORED_COLLEAGUE,
    INNOVATION,
    CUSTOMER_SATISFACTION
}

