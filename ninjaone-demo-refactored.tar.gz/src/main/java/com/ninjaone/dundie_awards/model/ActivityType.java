package com.ninjaone.dundie_awards.model;

public enum ActivityType {
    EMPLOYEE_CREATED,
    EMPLOYEE_UPDATED,
    AWARD_GRANTED,
    AWARD_REMOVED
}

