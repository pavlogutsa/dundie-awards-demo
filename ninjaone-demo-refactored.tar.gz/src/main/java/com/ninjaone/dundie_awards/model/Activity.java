package com.ninjaone.dundie_awards.model;

import jakarta.persistence.*;
import java.time.Instant;
import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;
import lombok.Builder;
import lombok.AccessLevel;
import lombok.NonNull;

@Entity
@Table(name = "activities")
@Getter
@Setter
@NoArgsConstructor
public class Activity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Setter(AccessLevel.NONE)
    private long id;

    @NonNull
    @Column(name = "occurred_at")
    private Instant occurredAt;

    @NonNull
    @Enumerated(EnumType.STRING)
    @Column(name = "event", nullable = false)
    private ActivityType event;

    @NonNull
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "employee_id", nullable = false)
    private Employee employee;

    @Builder
    private Activity(Instant occurredAt, ActivityType event, Employee employee) {
        this.occurredAt = occurredAt;
        this.event = event;
        this.employee = employee;
    }
}
