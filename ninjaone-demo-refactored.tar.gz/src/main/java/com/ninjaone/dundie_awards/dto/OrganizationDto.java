package com.ninjaone.dundie_awards.dto;

public record OrganizationDto(
    Long id,
    String name
) {}
