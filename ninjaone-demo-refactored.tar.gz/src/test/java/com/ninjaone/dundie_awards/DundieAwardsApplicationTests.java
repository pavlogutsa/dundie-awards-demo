package com.ninjaone.dundie_awards;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DundieAwardsApplicationTests {

	@Test
	void contextLoads() {
	}

}
