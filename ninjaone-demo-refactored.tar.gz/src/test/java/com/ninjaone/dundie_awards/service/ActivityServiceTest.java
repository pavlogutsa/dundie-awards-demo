package com.ninjaone.dundie_awards.service;

import com.ninjaone.dundie_awards.dto.ActivityDto;
import com.ninjaone.dundie_awards.exception.ActivityNotFoundException;
import com.ninjaone.dundie_awards.mapper.ActivityMapper;
import com.ninjaone.dundie_awards.model.Activity;
import com.ninjaone.dundie_awards.model.ActivityType;
import com.ninjaone.dundie_awards.model.Employee;
import com.ninjaone.dundie_awards.model.Organization;
import com.ninjaone.dundie_awards.repository.ActivityRepository;
import com.ninjaone.dundie_awards.repository.EmployeeRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.Instant;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ActivityServiceTest {

    @Mock
    private ActivityRepository activityRepository;

    @Mock
    private EmployeeRepository employeeRepository;

    @Mock
    private ActivityMapper activityMapper;

    @InjectMocks
    private ActivityService activityService;

    private Organization testOrganization;
    private Employee testEmployee;
    private Activity testActivity;
    private ActivityDto testActivityDto;

    @BeforeEach
    void setUp() {
        testOrganization = new Organization("Test Organization");
        testOrganization.setId(1L);

        testEmployee = new Employee("John", "Doe", testOrganization);
        testEmployee.setId(1L);
        testEmployee.setDundieAwards(0);

        Instant occurredAt = Instant.now();
        testActivity = new Activity(occurredAt, ActivityType.EMPLOYEE_CREATED, testEmployee);
        testActivity.setId(1L);

        testActivityDto = new ActivityDto(1L, occurredAt, 1L, ActivityType.EMPLOYEE_CREATED);
    }

    @Test
    void testGetAllActivities() {
        // Given
        Activity activity = new Activity(Instant.now(), ActivityType.EMPLOYEE_UPDATED, testEmployee);
        activity.setId(2L);
        List<Activity> activities = Arrays.asList(testActivity, activity);

        ActivityDto activityDto = new ActivityDto(2L, activity.getOccurredAt(), 1L, ActivityType.EMPLOYEE_UPDATED);
        List<ActivityDto> expectedDtos = Arrays.asList(testActivityDto, activityDto);

        when(activityRepository.findAll()).thenReturn(activities);
        when(activityMapper.toDtoList(activities)).thenReturn(expectedDtos);

        // When
        List<ActivityDto> result = activityService.getAllActivities();

        // Then
        assertThat(result).isNotNull();
        assertThat(result).hasSize(2);
        assertThat(result).isEqualTo(expectedDtos);
        verify(activityRepository).findAll();
        verify(activityMapper).toDtoList(activities);
    }

    @Test
    void testGetAllActivitiesWhenEmpty() {
        // Given
        when(activityRepository.findAll()).thenReturn(List.of());
        when(activityMapper.toDtoList(any())).thenReturn(List.of());

        // When
        List<ActivityDto> result = activityService.getAllActivities();

        // Then
        assertThat(result).isNotNull();
        assertThat(result).isEmpty();
        verify(activityRepository).findAll();
        verify(activityMapper).toDtoList(any());
    }

    @Test
    void testGetActivityById() {
        // Given
        when(activityRepository.findById(1L)).thenReturn(Optional.of(testActivity));
        when(activityMapper.toDto(testActivity)).thenReturn(testActivityDto);

        // When
        ActivityDto result = activityService.getActivity(1L);

        // Then
        assertThat(result).isNotNull();
        assertThat(result).isEqualTo(testActivityDto);
        assertThat(result.id()).isEqualTo(1L);
        assertThat(result.employeeId()).isEqualTo(1L);
        verify(activityRepository).findById(1L);
        verify(activityMapper).toDto(testActivity);
    }

    @Test
    void testGetActivityByIdNotFound() {
        // Given
        when(activityRepository.findById(999L)).thenReturn(Optional.empty());

        // When/Then
        assertThatThrownBy(() -> activityService.getActivity(999L))
                .isInstanceOf(ActivityNotFoundException.class)
                .hasMessage("Activity with id 999 not found");

        verify(activityRepository).findById(999L);
        verify(activityMapper, never()).toDto(any());
    }
}

