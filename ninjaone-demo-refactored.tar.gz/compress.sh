tar --exclude='./.git' --exclude='./.gradle' --exclude='./gradle' --exclude='./build' --exclude='./bin' -czvf ninjaone-demo-refactored.tar.gz .
